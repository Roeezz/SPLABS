#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

void encoder(bool debug, int encryption, const char *key, FILE *input, FILE *output, FILE *errorLog);
char encrypt(char original, int encryption, const char *key, int keyIndex);
char uppercase(char original, bool debug, FILE *output);

int main(int argc, char const *argv[])
{
	FILE *input = stdin;
	FILE *output = stdout;
	FILE *errorLog = stderr;
	bool debug = 0;
	int encryption = 0, keyPlace = 0;

	for (int i = 1; i < argc; i++)
	{
		if (strncmp(argv[i], "-D", 2) == 0)
		{
			debug = 1;
			for (int i = 1; i < argc; i++)
			{
				fprintf(errorLog, "%s\n", argv[i]);
			}
		}
		else if (strncmp("-e", argv[i], 2) == 0 || strncmp("+e", argv[i], 2) == 0)
		{
			if (argv[i][0] == '+')
			{
				encryption = 1;
			}
			else if (argv[i][0] == '-')
			{
				encryption = -1;
			}
			keyPlace = i;
		}
		else if (strncmp(argv[i], "-o", 2) == 0)
		{
			output = fopen(argv[i] + 2, "w");
		}
		else if (strncmp(argv[i], "-i", 2) == 0)
		{
			input = fopen(argv[i] + 2, "r");
			if (input == NULL)
			{
				fprintf(errorLog, "Could not open file %s", argv[i] + 2);
				return 1;
			}
		}
		else
		{
			fprintf(output, "Illegal program argument: %s", argv[i]);
			return 1;
		}
	}
	encoder(debug, encryption, argv[keyPlace], input, output, errorLog);
	return 0;
}

void encoder(bool debug, int encryption, const char *key, FILE *input, FILE *output, FILE *errorLog)
{
	char original;
	char encoded;
	int keyIndex = 0;

	while ((original = fgetc(input)) != EOF)
	{
		if (original == '\n')
		{
			if (debug)
				fputc('\n', errorLog);
			fputc('\n', output);
			keyIndex = 0;
		}
		else
		{
			if (encryption != 0)
			{
				encoded = encrypt(original, encryption, key, keyIndex);
				keyIndex = (keyIndex + 1) % (strlen(key) - 2);
			}
			else
			{
				encoded = uppercase(original, debug, output);
			}
			if (debug)
			{
				fprintf(errorLog, "%i   %i\n", original, encoded);
			}
			fputc(encoded, output);
		}
	}
	fclose(output);
}

char encrypt(char original, int encryption, const char *key, int keyIndex)
{
	int modification = (key[keyIndex + 2] - '0') * encryption;
	original = original + modification;

	return original;
}

char uppercase(char original, bool debug, FILE *output)
{
	int modificator = 32;
	if (97 <= original && original <= 122)
	{
		original = original - modificator;
	}

	return original;
}